import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const source = path.resolve(process.argv[2] ?? "");
const revision = "3d3a180f0400b84267f62969d42f8b102bed4479";
const directories = ["packages/statewire/core", "packages/statewire/durable-objects"];
const run = (cmd, args, cwd) => execFileSync(cmd, args, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "inherit"] });
if (!process.argv[2]) throw new Error("Usage: node scripts/package-runtime.mjs /path/to/harness-sdk");
if (existsSync(path.join(source, ".git"))) {
  if (run("git", ["rev-parse", "HEAD"], source).trim() !== revision) throw new Error("Source revision differs from pinned revision");
  if (run("git", ["status", "--porcelain", "--", ...directories], source).trim()) throw new Error("Package source must be clean");
} else if (readFileSync(path.join(source, ".source-revision"), "utf8").trim() !== revision) {
  throw new Error("Archive revision differs from pinned revision");
}
const vendor = path.join(root, "vendor");
mkdirSync(vendor, { recursive: true });
const artifacts = [];
for (const directory of directories) {
  const packageDir = path.join(source, directory);
  run("node", [path.join(source, "node_modules/@assistant-ui/x-buildutils/bin/aui-build.js")], packageDir);
  if (directory.endsWith("durable-objects")) run("node", ["scripts/postbuild.mjs"], packageDir);
  const staging = mkdtempSync(path.join(tmpdir(), "statewire-pack-"));
  try {
    cpSync(path.join(packageDir, "dist"), path.join(staging, "dist"), { recursive: true });
    cpSync(path.join(source, "LICENSE"), path.join(staging, "LICENSE"));
    const manifest = JSON.parse(readFileSync(path.join(packageDir, "package.json"), "utf8"));
    const normalizations = [];
    delete manifest.scripts;
    delete manifest.devDependencies;
    delete manifest.private;
    manifest.license = "MIT";
    manifest.files = ["dist", "LICENSE"];
    manifest.peerDependencies ??= {};
    for (const name of ["@assistant-ui/tap", "statewire"]) {
      const version = manifest.dependencies?.[name];
      if (!version) continue;
      delete manifest.dependencies[name];
      manifest.peerDependencies[name] = version;
      normalizations.push({ dependency: name, from: version, to: `required peer ${version}` });
    }
    for (const group of ["dependencies", "peerDependencies", "optionalDependencies"]) {
      for (const version of Object.values(manifest[group] ?? {})) {
        if (version.startsWith("workspace:") || version.startsWith("file:")) throw new Error("Unresolved local dependency");
      }
    }
    writeFileSync(path.join(staging, "package.json"), JSON.stringify(manifest, null, 2) + "\n");
    const [packed] = JSON.parse(run("npm", ["pack", "--ignore-scripts", "--json", "--pack-destination", vendor], staging));
    const sha256 = createHash("sha256").update(readFileSync(path.join(vendor, packed.filename))).digest("hex");
    artifacts.push({ name: manifest.name, version: manifest.version, directory, filename: packed.filename, sha256, normalizations });
  } finally { rmSync(staging, { recursive: true, force: true }); }
}
writeFileSync(path.join(vendor, "provenance.json"), JSON.stringify({ repository: "https://github.com/assistant-ui/harness-sdk", revision, artifacts }, null, 2) + "\n");
console.log(JSON.stringify(artifacts.map(({ filename, sha256 }) => ({ filename, sha256 })), null, 2));
