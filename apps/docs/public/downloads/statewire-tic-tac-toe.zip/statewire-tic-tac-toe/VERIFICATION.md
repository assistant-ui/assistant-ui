# Local verification — 2026-10-03

- Fresh dependency installation and `npm run build` passed TypeScript and Vite compilation.
- Two independent Chrome processes joined the same actual Wrangler Durable Object over WebSocket and received server-assigned X/O seats. A third visitor became a spectator.
- Browser moves completed an X win; all clients saw the same result. Reset synchronized the empty board. Another complete game ended in a draw.
- Direct protocol commands were rejected for out-of-turn play, spectator play, invalid square, occupied square, and game-over play.
- Two simultaneous same-turn commands from independent Statewire clients produced exactly one accepted move, one rejected move, and one board mark; the turn changed to O.
- Another room remained isolated with an empty board.
- A full Wrangler stop/restart restored the finished draw, board, turn, and player assignments. Reset remained functional after restart.
- Browser page errors: none.
- `wrangler deploy --dry-run` passed with static frontend assets, the Worker bundle, GAME binding, and SQLite migration. No production deployment performed.

The restart check waited over two seconds after the last command, allowing the adapter's one-second save debounce to complete. Local SQLite persistence is separate from Cloudflare production storage.

## Matchmaking and minimal dark UI update

- Two normal tabs in one browser automatically matched to the same unique room with distinct tab IDs. Separate browser contexts also matched. A window.open child got a distinct ID despite inherited session storage. Reload retained the tab's player seat.
- Moves and Play again synchronized after automatic matching. New match paired the two returning tabs into a different room. Cancel prevented the canceled visitor from consuming another visitor.
- A waiting entry without heartbeats expired after 30 seconds and did not match a fresh visitor; the next fresh visitor paired correctly.
- Copy link passed normal Clipboard API with actual clipboard-content verification, unavailable API fallback, denied API fallback, and blocked-both manual selectable-link cases.
- Desktop and 375px mobile layouts inspected; no horizontal overflow. Dark styling remained active regardless of system theme; no footer was rendered.
- TypeScript/Vite and deployment dry run passed with both GAME and LOBBY bindings. Existing persisted game state survived the binding update; live server remains on port 8797.

## Winning tiles and connection indicator

- The three actual winning cells (top row) had a staggered bounce at 0, 110, and 220 ms in both synchronized browser clients; other cells had no animation. Reset removed winning-cell animation classes.
- Reduced-motion emulation disabled the bounce while retaining the winning-cell markers.
- Disabled board tiles retained full opacity, with clearer dark-board borders and restrained green/yellow fills.
- The connected indicator was absent while connected. Connection state remains visible during connection failures or reconnection.
- Full win/draw, invalid-move, race and isolated-room checks passed again after the tab-identity update.
