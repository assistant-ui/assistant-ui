const key = "statewire-tic-tac-toe:tab-player";
const stored = sessionStorage.getItem(key);
export const playerId = stored && window.name === `statewire:${stored}` ? stored : crypto.randomUUID();
sessionStorage.setItem(key, playerId);
window.name = `statewire:${playerId}`;
