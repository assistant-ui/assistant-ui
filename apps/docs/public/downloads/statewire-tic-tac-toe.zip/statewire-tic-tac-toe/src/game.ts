export type Mark = "X" | "O";
export type GameState = {
  board: (Mark | null)[];
  players: Record<Mark, string | null>;
  turn: Mark;
  winner: Mark | null;
  phase: "playing" | "won" | "draw";
  round: number;
};
export type GameCommands = {
  join(playerId: string): void;
  play(playerId: string, cell: number): void;
  reset(playerId: string): void;
};
