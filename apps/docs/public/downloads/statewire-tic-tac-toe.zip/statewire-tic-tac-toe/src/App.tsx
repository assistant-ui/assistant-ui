import { useEffect, useState, type CSSProperties } from "react";
import { StatewireWebsocket, useStatewire } from "statewire";
import type { GameCommands, GameState } from "./game";
import { copyText } from "./copy";
import { playerId } from "./identity";

const room = new URLSearchParams(window.location.search).get("room") ?? "demo";

export const App = () => {
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [manualCopy, setManualCopy] = useState(false);
  const { state, commands, connection } = useStatewire<GameState | undefined, GameCommands>({
    transport: StatewireWebsocket({ url: `/game/${encodeURIComponent(room)}` }),
  });
  useEffect(() => {
    if (connection.status === "connected") void commands.join(playerId).catch(cause => setError(String(cause)));
  }, [connection.status, commands]);
  const mark = state?.players.X === playerId ? "X" : state?.players.O === playerId ? "O" : null;
  const waiting = !state?.players.X || !state?.players.O;
  const canPlay = !!state && !!mark && state.phase === "playing" && state.turn === mark && !waiting && connection.status === "connected";
  const send = async (action: () => Promise<void>) => {
    setError(null);
    try { await action(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
  };
  const winningCells = state?.phase === "won" ? [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]].find(line => line.every(index => state.board[index] === state.winner)) ?? [] : [];
  const status = !state ? "Connecting to the game…" : state.phase === "won" ? `${state.winner} wins!` : state.phase === "draw" ? "It's a draw." : waiting ? "Waiting for player O…" : state.turn === mark ? "Your turn." : `${state.turn}'s turn.`;
  return (
    <main>
      <header><a href="/" aria-label="Homepage">Tic Tac Toe</a>{connection.status !== "connected" && <div className="connection">{connection.status}</div>}</header>
      <section className="game">
        <div className="game-heading"><span className={`seat ${mark?.toLowerCase() ?? "spectator"}`}>{mark ? `You are ${mark}` : state ? "Spectator" : "Joining…"}</span></div>
        <h2 role="status">{status}</h2>
        <div className="board" aria-label="Tic-tac-toe board">
          {(state?.board ?? Array(9).fill(null)).map((cell, index) => <button type="button" key={index} className={`square ${cell?.toLowerCase() ?? ""} ${winningCells.includes(index) ? "winning" : ""}`} data-winning={winningCells.includes(index)} style={{ "--bounce-delay": `${Math.max(0, winningCells.indexOf(index)) * 110}ms` } as CSSProperties} aria-label={`Square ${index + 1}${cell ? `: ${cell}` : ""}`} disabled={!canPlay || cell !== null} onClick={() => void send(() => commands.play(playerId, index))}>{cell}</button>)}
        </div>
        <div className="players"><span className="x">X <small>{state?.players.X ? "ready" : "waiting"}</small></span><span className="o">O <small>{state?.players.O ? "ready" : "waiting"}</small></span></div>
        <div className="actions"><button type="button" disabled={!mark || connection.status !== "connected"} onClick={() => void send(() => commands.reset(playerId))}>Play again</button><button type="button" className="secondary" onClick={() => void copyText(window.location.href).then(success => { setCopied(success); setManualCopy(!success); })}>{copied ? "Link copied" : "Copy link"}</button></div>
        {manualCopy && <label className="manual-copy">Copy this link<input name="room-link" aria-label="Room link" readOnly value={window.location.href} onFocus={event => event.currentTarget.select()} /></label>}
        <a className="rematch" href={`/?rematch=1${new URLSearchParams(window.location.search).has("lobby") ? `&lobby=${encodeURIComponent(new URLSearchParams(window.location.search).get("lobby")!)}` : ""}`}>New match</a>
        {error && <p role="alert">{error}</p>}
      </section>

    </main>
  );
};
