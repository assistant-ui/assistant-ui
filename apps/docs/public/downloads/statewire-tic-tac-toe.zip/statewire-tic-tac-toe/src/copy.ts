export const copyText = async (text: string): Promise<boolean> => {
  const fallback = () => {
    const field = document.createElement("textarea");
    field.value = text;
    field.style.position = "fixed";
    field.style.opacity = "0";
    document.body.appendChild(field);
    field.focus();
    field.select();
    try { return document.execCommand("copy"); }
    catch { return false; }
    finally { field.remove(); }
  };
  if (!navigator.clipboard?.writeText) return fallback();
  try { await navigator.clipboard.writeText(text); return true; }
  catch { return fallback(); }
};
