import { createRoot } from "react-dom/client";
import { App } from "./App";
import "./style.css";
import { LobbyView } from "./LobbyView";
createRoot(document.getElementById("root")!).render(new URLSearchParams(window.location.search).has("room") ? <App /> : <LobbyView />);
