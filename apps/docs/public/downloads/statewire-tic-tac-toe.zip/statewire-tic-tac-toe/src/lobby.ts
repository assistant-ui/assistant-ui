export type LobbyState = { waiting: Record<string, number>; matches: Record<string, { room: string; at: number }> };
export type LobbyCommands = { join(id: string): void; heartbeat(id: string): void; cancel(id: string): void; rematch(id: string): void };
