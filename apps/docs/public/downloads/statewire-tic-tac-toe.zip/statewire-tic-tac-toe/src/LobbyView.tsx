import { useEffect, useRef, useState } from "react";
import { StatewireWebsocket, useStatewire } from "statewire";
import { playerId } from "./identity";
import type { LobbyCommands, LobbyState } from "./lobby";

const lobbyName = new URLSearchParams(window.location.search).get("lobby") ?? "main";

export const LobbyView = () => {
  const [paused, setPaused] = useState(false);
  const [registered, setRegistered] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const rematch = useRef(new URLSearchParams(window.location.search).has("rematch"));
  const { state, commands, connection } = useStatewire<LobbyState | undefined, LobbyCommands>({ transport: StatewireWebsocket({ url: `/lobby/${encodeURIComponent(lobbyName)}` }) });
  const match = state?.matches[playerId];
  useEffect(() => {
    if (connection.status !== "connected" || paused) return;
    const action = rematch.current ? commands.rematch(playerId) : commands.join(playerId);
    rematch.current = false;
    window.history.replaceState(null, "", lobbyName === "main" ? "/" : `/?lobby=${encodeURIComponent(lobbyName)}`);
    void action.then(() => setRegistered(true)).catch(cause => setError(String(cause)));
    const timer = setInterval(() => void commands.heartbeat(playerId).catch(cause => setError(String(cause))), 7000);
    return () => { clearInterval(timer); };
  }, [connection.status, commands, paused]);
  useEffect(() => {
    if (match && registered) window.location.replace(`/?room=${encodeURIComponent(match.room)}${lobbyName === "main" ? "" : `&lobby=${encodeURIComponent(lobbyName)}`}`);
  }, [match, registered]);
  const cancel = async () => {
    try { await commands.cancel(playerId); setPaused(true); }
    catch (cause) { setError(String(cause)); }
  };
  return <main>
    <header><a href="/" aria-label="Homepage">Tic Tac Toe</a></header>
    <section className="lobby">
      <h1>{paused ? "Matchmaking paused" : match ? "Match found" : "Finding an opponent"}</h1>
      {connection.status !== "connected" && <p className="connection">{connection.status}</p>}
      {paused ? <button type="button" onClick={() => setPaused(false)}>Find a match</button> : <button type="button" className="secondary" disabled={connection.status !== "connected"} onClick={() => void cancel()}>Cancel</button>}
      {error && <p role="alert">{error}</p>}
    </section>
  </main>;
};
