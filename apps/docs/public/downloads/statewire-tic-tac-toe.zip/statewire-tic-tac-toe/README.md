# Statewire tic-tac-toe on Cloudflare Durable Objects

A multiplayer game with a real server-owned board, turns, X/O seats, wins and draws. Commands execute in a Cloudflare Durable Object and state replicates over WebSocket to every browser. The game and player assignments persist across Worker restarts.

## Run the demo

Requires Node.js 22.12 or newer and npm. Unzip, open the directory, then:

```sh
npm install
npm run dev
```

Open http://localhost:8797/ in two tabs or browsers. The lobby automatically pairs the first waiting visitor with the next visitor, assigns a unique game room, and opens that game in both tabs. The game server assigns X/O seats; X moves first.

- Each tab has its own player ID in session storage, retained across reloads. Opening another tab creates another player. Tabs opened with `window.open` also receive distinct IDs despite copied session storage.
- The lobby sends a heartbeat every seven seconds. Waiting entries expire after 30 seconds without a heartbeat; abandoned tabs stop occupying the queue after that grace period.
- **Cancel** pauses matchmaking; **Find a match** resumes it.
- **Play again** resets the current board and keeps X/O assignments. **New match** enters the lobby for another opponent.
- **Copy link** shares an explicit `?room=...` game URL. Extra visitors to a full game spectate. When clipboard access is unavailable or denied, a fallback copy is attempted; if both methods are blocked, a selectable URL is shown for manual copying.
- An explicit `?room=your-room` joins a shared game directly. A `?lobby=your-lobby` query selects an independent matchmaking queue; the default queue is `main`.
- The UI is dark only, with compact square tiles and no instructional footer. Player seats stay reserved when someone leaves a game; choose **New match** for another opponent.

This is a public presentation demo. Player IDs are tab-generated identifiers, not authenticated credentials. Anyone with the room URL can watch; this starter does not provide private rooms or protect against an adversary impersonating a known player ID. Add application authentication before using it for private or competitive games.

## Persistence

Wait at least two seconds after a move, stop Wrangler with Ctrl+C, then run `npm run dev` again. The same room restores its board, turn, result, and player seats from `.wrangler/state`.

The adapter saves on a one-second debounce and flushes on connection close. Abrupt termination before a pending save can lose recent changes. Local saved state is separate from production storage.

## Deploy

Choose a unique Worker name in `wrangler.jsonc`, then:

```sh
npx wrangler login
npm run deploy
```

Cloudflare account access is required for deployment. The Worker serves the frontend and `/game/<room>` Statewire WebSocket route. Its `GAME` and `LOBBY` bindings use the exported `Game` and `Lobby` classes with SQLite Durable Object migrations; no separate database or API key is needed.

## Source and verification

- `worker/index.ts` implements authoritative `join`, `play`, and `reset` commands. Synchronous handlers serialize concurrent moves, so two same-turn requests cannot both occupy squares.
- `worker/lobby.ts` implements authoritative matchmaking, queue cancellation, rematching, and stale-waiter expiry using another Statewire Durable Object.
- `src/game.ts` defines the shared typed state and command contract.
- `src/App.tsx` reads actual replicated state; no optimistic or client-only game board is used.
- `vendor/` includes MIT-licensed official-source Statewire 0.19.3 and Durable Objects adapter 0.2.0 at revision `3d3a180f0400b84267f62969d42f8b102bed4479` of https://github.com/assistant-ui/harness-sdk.
- Required tap/statewire peer normalizations ensure one shared runtime. `vendor/provenance.json` records exact package versions, SHA-256 hashes, and manifest transformations. These archives are not published npm releases.
- `VERIFICATION.md` records local browser, command-validation, concurrent-move, persistence, and deploy dry-run checks.

To rebuild the bundled archives from official source:

```sh
git clone https://github.com/assistant-ui/harness-sdk.git /tmp/statewire-source
cd /tmp/statewire-source
git checkout 3d3a180f0400b84267f62969d42f8b102bed4479
pnpm install --frozen-lockfile
cd /path/to/statewire-tic-tac-toe
node scripts/package-runtime.mjs /tmp/statewire-source
```

MIT license is included at the root and inside each archive. After frontend edits, restart `npm run dev` to rebuild the assets. `npm run build` runs TypeScript and Vite production compilation.
