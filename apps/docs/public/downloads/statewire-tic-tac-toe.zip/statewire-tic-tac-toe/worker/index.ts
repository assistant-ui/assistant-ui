import { resource } from "@assistant-ui/tap";
import { getStateHost, StatewireReject, useStatewireCommands, useStatewireState } from "statewire/host";
import { StatewireDurableObject, routeStatewireRequest } from "statewire-durable-objects";
import type { GameState, Mark } from "../src/game";

export { Lobby } from "./lobby";

type Env = { LOBBY: StatewireDurableObject.Namespace; GAME: StatewireDurableObject.Namespace; ASSETS: Fetcher };
const lines = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const winnerOf = (board: GameState["board"]): Mark | null => {
  for (const [a, b, c] of lines) if (board[a] !== null && board[a] === board[b] && board[a] === board[c]) return board[a];
  return null;
};
const emptyGame = (): GameState => ({ board: Array(9).fill(null), players: { X: null, O: null }, turn: "X", winner: null, phase: "playing", round: 1 });
const validatePlayerId = (id: string) => {
  if (typeof id !== "string" || !/^[a-zA-Z0-9_-]{8,80}$/.test(id)) throw new StatewireReject("Invalid player ID");
};
const restoreGame = (restored: unknown): GameState => {
  if (restored === undefined) return emptyGame();
  if (typeof restored !== "object" || restored === null) throw new Error("Invalid saved game");
  const state = restored as GameState;
  if (!Array.isArray(state.board) || state.board.length !== 9 || state.board.some(cell => cell !== null && cell !== "X" && cell !== "O")) throw new Error("Invalid saved board");
  if (!state.players || ![state.players.X, state.players.O].every(id => id === null || typeof id === "string" && /^[a-zA-Z0-9_-]{8,80}$/.test(id))) throw new Error("Invalid saved players");
  if (state.players.X !== null && state.players.X === state.players.O) throw new Error("Player seats must differ");
  const x = state.board.filter(cell => cell === "X").length;
  const o = state.board.filter(cell => cell === "O").length;
  const winner = winnerOf(state.board);
  const phase = winner ? "won" : state.board.every(Boolean) ? "draw" : "playing";
  if ((x !== o && x !== o + 1) || !["X", "O"].includes(state.turn) || state.winner !== winner || state.phase !== phase || !Number.isSafeInteger(state.round) || state.round < 1) throw new Error("Invalid saved game state");
  if (phase === "playing" && state.turn !== (x === o ? "X" : "O")) throw new Error("Invalid saved turn");
  return state;
};

const GameHost = resource((restored: unknown) => {
  const [state] = useStatewireState(() => restoreGame(restored));
  const commands = useStatewireCommands({
    join: (playerId: string) => {
      validatePlayerId(playerId);
      if (state.players.X === playerId || state.players.O === playerId) return;
      if (state.players.X === null) state.players.X = playerId;
      else if (state.players.O === null) state.players.O = playerId;
    },
    play: (playerId: string, cell: number) => {
      validatePlayerId(playerId);
      if (!Number.isInteger(cell) || cell < 0 || cell > 8) throw new StatewireReject("Choose a valid square");
      if (state.players.X !== playerId && state.players.O !== playerId) throw new StatewireReject("Spectators cannot make moves");
      if (state.phase !== "playing") throw new StatewireReject("This game is finished. Start a new game");
      if (!state.players.X || !state.players.O) throw new StatewireReject("Waiting for the second player");
      if (state.players[state.turn] !== playerId) throw new StatewireReject("It is not your turn");
      if (state.board[cell] !== null) throw new StatewireReject("That square is already taken");
      state.board[cell] = state.turn;
      state.winner = winnerOf(state.board);
      if (state.winner) state.phase = "won";
      else if (state.board.every(Boolean)) state.phase = "draw";
      else state.turn = state.turn === "X" ? "O" : "X";
    },
    reset: (playerId: string) => {
      validatePlayerId(playerId);
      if (state.players.X !== playerId && state.players.O !== playerId) throw new StatewireReject("Only players can start a new game");
      state.board = Array(9).fill(null);
      state.turn = "X";
      state.winner = null;
      state.phase = "playing";
      state.round += 1;
    },
  });
  const source = getStateHost(state)!;
  return {
    state, commands, snapshot: source.snapshot,
    subscribe: (listener: () => void) => { source.setOnChange(listener); return () => source.setOnChange(null); },
  };
});

export class Game extends StatewireDurableObject<Env>((restored) => GameHost(restored)) {}
export default {
  fetch: (request: Request, env: Env) => {
    const response = routeStatewireRequest(request, env);
    if (response) return response;
    if (["/game/", "/lobby/"].some(prefix => new URL(request.url).pathname.startsWith(prefix))) return new Response("Not found", { status: 404 });
    return env.ASSETS.fetch(request);
  },
};
