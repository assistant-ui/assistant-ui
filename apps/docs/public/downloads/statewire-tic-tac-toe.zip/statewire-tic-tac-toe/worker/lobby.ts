import { resource } from "@assistant-ui/tap";
import { getStateHost, StatewireReject, useStatewireCommands, useStatewireState } from "statewire/host";
import { StatewireDurableObject } from "statewire-durable-objects";
import type { LobbyState } from "../src/lobby";

export const waitingTtlMs = 30_000;
const validId = (id: string) => {
  if (typeof id !== "string" || !/^[a-zA-Z0-9_-]{8,80}$/.test(id)) throw new StatewireReject("Invalid player ID");
};
const LobbyHost = resource((restored: unknown) => {
  const [state] = useStatewireState<LobbyState>(() => {
    if (restored === undefined) return { waiting: {}, matches: {} };
    if (typeof restored !== "object" || restored === null || !("waiting" in restored) || !("matches" in restored)) throw new Error("Invalid saved lobby");
    return restored as LobbyState;
  });
  const cleanup = () => {
    const now = Date.now();
    for (const [id, seen] of Object.entries(state.waiting)) if (now - seen > waitingTtlMs) delete state.waiting[id];
    for (const [id, match] of Object.entries(state.matches)) if (now - match.at > 86_400_000) delete state.matches[id];
  };
  const join = (id: string) => {
    validId(id);
    cleanup();
    if (state.matches[id]) return;
    const other = Object.keys(state.waiting).find(candidate => candidate !== id);
    if (!other) { state.waiting[id] = Date.now(); return; }
    const room = crypto.randomUUID();
    const at = Date.now();
    state.matches[id] = { room, at };
    state.matches[other] = { room, at };
    delete state.waiting[id];
    delete state.waiting[other];
  };
  const commands = useStatewireCommands({
    join,
    heartbeat: (id: string) => {
      validId(id);
      cleanup();
      if (state.waiting[id] !== undefined) state.waiting[id] = Date.now();
    },
    cancel: (id: string) => { validId(id); delete state.waiting[id]; },
    rematch: (id: string) => { validId(id); delete state.waiting[id]; delete state.matches[id]; join(id); },
  });
  const source = getStateHost(state)!;
  return { state, commands, snapshot: source.snapshot, subscribe: (listener: () => void) => { source.setOnChange(listener); return () => source.setOnChange(null); } };
});
export class Lobby extends StatewireDurableObject((restored) => LobbyHost(restored)) {}
